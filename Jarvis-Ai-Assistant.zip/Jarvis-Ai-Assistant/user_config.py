gmail_password = "Your Email Password"
openai_key="Your OpenAI API Key"