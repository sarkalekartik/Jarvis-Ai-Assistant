import os
import pyttsx3  # type: ignore
import speech_recognition as sr
import random
import webbrowser
import datetime
from plyer import notification
import pyautogui
import wikipedia
import user_config
import openai_request as ai
import mtranslate

# Text-to-speech engine setup
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)
engine.setProperty("rate", 170)

# Speak function
def speak(audio):
    audio = mtranslate.translate(audio, to_language="en", from_language="en-in")
    print(audio)
    engine.say(audio)
    engine.runAndWait()

# Voice command capture
def command():
    content = " "
    while content == " ":
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Say something!")
            audio = r.listen(source)
        try:
            content = r.recognize_google(audio, language='en-in')
            content = mtranslate.translate(content, to_language='en-in')
            print("You Said...." + content)
        except Exception:
            print("Please try again...")
    return content

# Main voice assistant loop
def main_process():
    jarvis_chat = []
    while True:
        request = command().lower()

        if "hello" in request:
            speak("Welcome, how can I help you.")

        elif "play music" in request:
            speak("Playing music")
            song = random.randint(1, 5)
            songs = [
                "https://www.youtube.com/watch?v=HCWvgoTfUjg",
                "https://www.youtube.com/watch?v=UbgBidiaiZA",
                "https://www.youtube.com/watch?v=sZiETQzgAPc",
                "https://www.youtube.com/watch?v=6nQLoPwGsMM",
                "https://www.youtube.com/watch?v=5CSuwo_6ggc"
            ]
            webbrowser.open(songs[song - 1])

        elif "say time" in request:
            now_time = datetime.datetime.now().strftime("%H:%M")
            speak("Current time is " + str(now_time))

        elif "say date" in request:
            now_time = datetime.datetime.now().strftime("%d:%m")
            speak("Current date is " + str(now_time))

        elif "new task" in request:
            task = request.replace("new task", "").strip()
            if task:
                speak("Adding task: " + task)
                with open("todo.txt", "a") as file:
                    file.write(task + "\n")

        elif "speak task" in request:
            try:
                with open("todo.txt", "r") as file:
                    speak("Work we have to do today is: " + file.read())
            except FileNotFoundError:
                speak("No tasks found.")

        elif "show work" in request:
            try:
                with open("todo.txt", "r") as file:
                    tasks = file.read()
                notification.notify(
                    title="Today's work",
                    message=tasks
                )
            except FileNotFoundError:
                speak("No tasks found to display.")

        elif "open youtube" in request:
            webbrowser.open("https://www.youtube.com/")
            speak("Opening YouTube")

        elif "open whatsapp" in request:
            webbrowser.open("https://web.whatsapp.com/")
            speak("Opening WhatsApp")

        elif "open instagram" in request:
            webbrowser.open("https://www.instagram.com/")
            speak("Opening Instagram")

        elif "open facebook" in request:
            webbrowser.open("https://www.facebook.com/")
            speak("Opening Facebook")

        elif "open google" in request:
            webbrowser.open("https://www.google.com/")
            speak("Opening Google")

        elif "open vs code" in request:
            webbrowser.open("https://code.visualstudio.com/")
            speak("Opening Visual Studio Code")

        elif "open" in request:
            query = request.replace("open", "").strip()
            pyautogui.press("super")
            pyautogui.typewrite(query)
            pyautogui.sleep(2)
            pyautogui.press("enter")

        elif "wikipedia" in request:
            request = request.replace("jarvis", "").replace("search wikipedia", "")
            result = wikipedia.summary(request, sentences=3)
            print(result)
            speak(result)

        elif "search google" in request:
            request = request.replace("jarvis", "").replace("search google", "")
            webbrowser.open("https://www.google.com/search?q=" + request)

        elif "search gemini" in request:
            request = request.replace("jarvis", "").replace("search gemini", "")
            webbrowser.open("https://gemini.google.com/search?q=" + request)

        elif "ask ai" in request:
            request = request.replace("jarvis", "").replace("ask ai", "")
            jarvis_chat.append({"role": "user", "content": request})
            response = ai.send_request(jarvis_chat)
            print(response)
            speak(response)

        else:
            request = request.replace("jarvis", "")
            jarvis_chat.append({"role": "user", "content": request})
            response = ai.send_request2(jarvis_chat)
            jarvis_chat.append({"role": "assistant", "content": response})
            print(response)
            speak(response)

main_process()
